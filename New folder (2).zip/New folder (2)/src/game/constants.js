export const BUCKET_WIDTH = 400;
export const BUCKET_HEIGHT = 450;
export const BUCKET_THICKNESS = 20;
export const SCALE = [0.38, 0.51, 0.56, 0.7, 0.65, 0.65, 0.73, 0.62, 0.58, 0.65, 0.54];
export const FRUIT_CATEGORY = 0x0002;
export const BUCKET_CATEGORY = 0x0004;
export const MOUSE_CATEGORY = 0x0001;
 